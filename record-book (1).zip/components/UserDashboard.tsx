import React, { useMemo, useState } from 'react';
import { User, Expense, ExpenseCategory } from '../types';
import { ExpenseItem } from './ExpenseItem';
import { AddExpenseForm } from './AddExpenseForm';
import { PlusCircle, Calendar, DollarSign, Filter } from 'lucide-react';

interface UserDashboardProps {
  user: User;
  expenses: Expense[];
  onAddExpense: (expense: Omit<Expense, 'id' | 'userId'>) => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({ user, expenses, onAddExpense }) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Filter expenses for this user and selected category
  const userExpenses = useMemo(() => {
    return expenses
      .filter(e => {
        const matchesUser = e.userId === user.id;
        const matchesCategory = selectedCategory === 'All' || e.category === selectedCategory;
        return matchesUser && matchesCategory;
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [expenses, user.id, selectedCategory]);

  // Calculate monthly total (based on filtered view)
  const monthlyTotal = useMemo(() => {
    const now = new Date();
    return userExpenses
      .filter(e => {
        const d = new Date(e.date);
        return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      })
      .reduce((sum, e) => sum + e.amount, 0);
  }, [userExpenses]);

  // Calculate daily average (simple)
  const dailyAverage = useMemo(() => {
    // Avoid division by zero if list is empty or filtered out
    if (userExpenses.length === 0) return 0;
    
    const now = new Date();
    const daysInMonth = now.getDate(); // Just avg over days passed
    return monthlyTotal / (daysInMonth || 1);
  }, [monthlyTotal, userExpenses]);

  const handleAddSubmit = (amount: number, description: string, category: string, date: string) => {
    onAddExpense({ amount, description, category, date });
    setShowAddForm(false);
    // Optionally reset filter to All or the new category so user sees the new item
    if (selectedCategory !== 'All' && selectedCategory !== category) {
      setSelectedCategory('All');
    }
  };

  const categories = ['All', ...Object.values(ExpenseCategory)];

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Header Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl p-5 text-white shadow-lg transition-all duration-300">
          <div className="flex items-center gap-2 mb-1 opacity-90">
            <DollarSign size={18} />
            <span className="text-sm font-medium">{selectedCategory === 'All' ? 'Month Total' : `${selectedCategory} Total`}</span>
          </div>
          <p className="text-3xl font-bold tracking-tight">${monthlyTotal.toFixed(2)}</p>
        </div>
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 transition-all duration-300">
          <div className="flex items-center gap-2 mb-1 text-gray-500">
            <Calendar size={18} />
            <span className="text-sm font-medium">Daily Avg</span>
          </div>
          <p className="text-3xl font-bold text-gray-800">${dailyAverage.toFixed(2)}</p>
        </div>
      </div>

      {/* Action Bar */}
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-gray-800">History</h2>
        {!showAddForm && (
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gray-900 text-white rounded-full hover:bg-gray-800 transition-colors text-sm font-medium shadow-md"
          >
            <PlusCircle size={16} /> Add Expense
          </button>
        )}
      </div>

      {/* Add Form */}
      {showAddForm && (
        <div className="mb-6">
          <AddExpenseForm onAdd={handleAddSubmit} onCancel={() => setShowAddForm(false)} />
        </div>
      )}

      {/* Category Filter */}
      {!showAddForm && (
        <div className="flex gap-2 overflow-x-auto pb-2 -mx-2 px-2 scrollbar-hide">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-medium transition-all duration-200 border ${
                selectedCategory === cat
                  ? 'bg-indigo-600 border-indigo-600 text-white shadow-md'
                  : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50 hover:border-gray-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      )}

      {/* Expense List */}
      <div className="space-y-3">
        {userExpenses.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-gray-300">
            {selectedCategory === 'All' ? (
              <p className="text-gray-400">No expenses yet. Good job saving!</p>
            ) : (
              <div className="space-y-2">
                <div className="flex justify-center text-gray-300">
                   <Filter size={32} />
                </div>
                <p className="text-gray-400">No expenses found for {selectedCategory}.</p>
                <button 
                  onClick={() => setSelectedCategory('All')}
                  className="text-indigo-600 text-sm font-medium hover:underline"
                >
                  Clear filter
                </button>
              </div>
            )}
          </div>
        ) : (
          userExpenses.map(expense => (
            <ExpenseItem key={expense.id} expense={expense} />
          ))
        )}
      </div>
    </div>
  );
};