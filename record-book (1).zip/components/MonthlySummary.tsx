import React, { useMemo, useState } from 'react';
import { User, Expense } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { generateSpendingInsight } from '../services/geminiService';
import { Sparkles, Trophy } from 'lucide-react';

interface MonthlySummaryProps {
  users: User[];
  expenses: Expense[];
}

export const MonthlySummary: React.FC<MonthlySummaryProps> = ({ users, expenses }) => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);

  const currentMonthData = useMemo(() => {
    const now = new Date();
    const currentMonthExpenses = expenses.filter(e => {
      const d = new Date(e.date);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    });

    return users.map(user => {
      const total = currentMonthExpenses
        .filter(e => e.userId === user.id)
        .reduce((sum, e) => sum + e.amount, 0);
      return {
        name: user.name,
        total: total,
        userId: user.id,
        avatar: user.avatar
      };
    }).sort((a, b) => b.total - a.total); // Sort highest first for "thief" logic
  }, [users, expenses]);

  const maxSpender = currentMonthData[0];
  const totalPool = currentMonthData.reduce((acc, curr) => acc + curr.total, 0);

  const handleGenerateInsight = async () => {
    setLoadingInsight(true);
    setInsight(null);
    const result = await generateSpendingInsight(users, expenses);
    setInsight(result);
    setLoadingInsight(false);
  };

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      
      {/* Hero Card */}
      <div className="bg-gray-900 text-white rounded-3xl p-8 text-center shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-indigo-500 via-purple-500 to-transparent"></div>
        <h2 className="text-3xl font-bold mb-2 relative z-10">Total Pool</h2>
        <p className="text-5xl font-extrabold tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-green-300 to-emerald-400 relative z-10">
          ${totalPool.toFixed(2)}
        </p>
        <p className="text-gray-400 mt-2 text-sm relative z-10 uppercase tracking-widest">Current Month</p>
      </div>

      {/* Leaderboard */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-gray-800 px-1">Spending Leaderboard</h3>
        {currentMonthData.map((data, index) => {
          const isThief = index === 0 && data.total > 0;
          return (
            <div 
              key={data.userId} 
              className={`relative flex items-center justify-between p-5 rounded-2xl border transition-all ${
                isThief 
                ? 'bg-red-50 border-red-200 shadow-sm ring-1 ring-red-100' 
                : 'bg-white border-gray-100'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="relative">
                   <img src={data.avatar} alt={data.name} className="w-12 h-12 rounded-full object-cover border-2 border-white shadow-sm" />
                   {index === 0 && <div className="absolute -top-2 -right-2 bg-yellow-400 text-xs font-bold px-1.5 py-0.5 rounded-full shadow-sm text-yellow-900">#1</div>}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-bold text-gray-900 text-lg">{data.name}</p>
                    {isThief && <span className="text-2xl animate-pulse" title="The Thief!">🥷</span>}
                  </div>
                  <p className="text-xs text-gray-500 font-medium">
                    {((data.total / (totalPool || 1)) * 100).toFixed(0)}% of total
                  </p>
                </div>
              </div>
              <p className="text-xl font-bold text-gray-900">${data.total.toFixed(2)}</p>
            </div>
          );
        })}
      </div>

      {/* Chart */}
      <div className="h-64 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">Comparison</h3>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={currentMonthData}>
            <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} dy={10} />
            <Tooltip 
              cursor={{fill: 'transparent'}}
              contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
            />
            <Bar dataKey="total" radius={[8, 8, 8, 8]} barSize={40}>
              {currentMonthData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={index === 0 ? '#ef4444' : '#6366f1'} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* AI Insight Section */}
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl p-6 border border-indigo-100">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 text-indigo-900 font-bold">
            <Sparkles size={20} className="text-indigo-600" />
            <span>AI Spending Analyst</span>
          </div>
          <button 
            onClick={handleGenerateInsight}
            disabled={loadingInsight}
            className="text-xs bg-indigo-600 text-white px-3 py-1.5 rounded-full hover:bg-indigo-700 transition disabled:opacity-50"
          >
            {loadingInsight ? 'Analyzing...' : 'Ask AI'}
          </button>
        </div>
        
        {insight ? (
          <p className="text-gray-700 text-sm leading-relaxed italic border-l-4 border-indigo-300 pl-3">
            "{insight}"
          </p>
        ) : (
          <p className="text-gray-500 text-sm">
            Hit the button to see who the AI thinks needs to cut back on avocado toast.
          </p>
        )}
      </div>
    </div>
  );
};