import React from 'react';
import { Expense, ExpenseCategory } from '../types';
import { ShoppingBag, Coffee, Car, Zap, Clapperboard, HelpCircle } from 'lucide-react';

interface ExpenseItemProps {
  expense: Expense;
}

const getCategoryIcon = (category: string) => {
  switch (category) {
    case ExpenseCategory.FOOD: return <Coffee size={18} className="text-orange-500" />;
    case ExpenseCategory.SHOPPING: return <ShoppingBag size={18} className="text-blue-500" />;
    case ExpenseCategory.TRANSPORT: return <Car size={18} className="text-green-500" />;
    case ExpenseCategory.UTILITIES: return <Zap size={18} className="text-yellow-500" />;
    case ExpenseCategory.ENTERTAINMENT: return <Clapperboard size={18} className="text-purple-500" />;
    default: return <HelpCircle size={18} className="text-gray-400" />;
  }
};

export const ExpenseItem: React.FC<ExpenseItemProps> = ({ expense }) => {
  const date = new Date(expense.date);
  
  return (
    <div className="flex items-center justify-between p-4 bg-white rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
      <div className="flex items-center gap-3">
        <div className="p-2 bg-gray-50 rounded-lg">
          {getCategoryIcon(expense.category)}
        </div>
        <div>
          <p className="font-medium text-gray-800">{expense.description}</p>
          <p className="text-xs text-gray-500">
            {date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} • {expense.category}
          </p>
        </div>
      </div>
      <span className="font-semibold text-gray-900">
        ${expense.amount.toFixed(2)}
      </span>
    </div>
  );
};