export interface User {
  id: string;
  name: string;
  avatar: string;
}

export interface Expense {
  id: string;
  userId: string;
  amount: number;
  date: string; // ISO String
  description: string;
  category: string;
}

export interface MonthlyStats {
  userId: string;
  total: number;
}

export type ViewState = 'dashboard' | 'summary';

export enum ExpenseCategory {
  FOOD = 'Food',
  TRANSPORT = 'Transport',
  UTILITIES = 'Utilities',
  ENTERTAINMENT = 'Entertainment',
  SHOPPING = 'Shopping',
  OTHER = 'Other',
}