import { User, Expense, ExpenseCategory } from './types';

export const USERS: User[] = [
  { id: 'u1', name: 'Alice', avatar: 'https://ui-avatars.com/api/?name=Alice&background=random' },
  { id: 'u2', name: 'Bob', avatar: 'https://ui-avatars.com/api/?name=Bob&background=random' },
  { id: 'u3', name: 'Charlie', avatar: 'https://ui-avatars.com/api/?name=Charlie&background=random' },
];

const generateId = () => Math.random().toString(36).substr(2, 9);
const today = new Date();
const yesterday = new Date(today);
yesterday.setDate(yesterday.getDate() - 1);
const lastWeek = new Date(today);
lastWeek.setDate(lastWeek.getDate() - 7);

export const INITIAL_EXPENSES: Expense[] = [
  { id: generateId(), userId: 'u1', amount: 12.50, date: today.toISOString(), description: 'Lunch', category: ExpenseCategory.FOOD },
  { id: generateId(), userId: 'u1', amount: 45.00, date: yesterday.toISOString(), description: 'Gas', category: ExpenseCategory.TRANSPORT },
  { id: generateId(), userId: 'u2', amount: 120.00, date: today.toISOString(), description: 'New Keyboard', category: ExpenseCategory.SHOPPING },
  { id: generateId(), userId: 'u2', amount: 15.00, date: lastWeek.toISOString(), description: 'Netflix', category: ExpenseCategory.ENTERTAINMENT },
  { id: generateId(), userId: 'u3', amount: 8.00, date: today.toISOString(), description: 'Coffee', category: ExpenseCategory.FOOD },
  { id: generateId(), userId: 'u3', amount: 250.00, date: yesterday.toISOString(), description: 'Grocery Run', category: ExpenseCategory.FOOD },
];