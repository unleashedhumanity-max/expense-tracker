import React, { useState, useEffect } from 'react';
import { USERS, INITIAL_EXPENSES } from './constants';
import { User, Expense, ViewState } from './types';
import { UserDashboard } from './components/UserDashboard';
import { MonthlySummary } from './components/MonthlySummary';
import { Wallet, Users, LayoutDashboard, LogOut } from 'lucide-react';

const App: React.FC = () => {
  const [activeUser, setActiveUser] = useState<User | null>(USERS[0]);
  const [view, setView] = useState<ViewState>('dashboard');
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('expenses');
    return saved ? JSON.parse(saved) : INITIAL_EXPENSES;
  });

  // Persist expenses
  useEffect(() => {
    localStorage.setItem('expenses', JSON.stringify(expenses));
  }, [expenses]);

  const handleAddExpense = (newExpenseData: Omit<Expense, 'id' | 'userId'>) => {
    if (!activeUser) return;
    
    const newExpense: Expense = {
      id: Math.random().toString(36).substr(2, 9),
      userId: activeUser.id,
      ...newExpenseData
    };
    
    setExpenses(prev => [newExpense, ...prev]);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto shadow-2xl overflow-hidden relative">
      
      {/* Top Navigation Bar */}
      <header className="bg-white px-6 py-4 flex items-center justify-between sticky top-0 z-50 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
            <Wallet size={18} strokeWidth={2.5} />
          </div>
          <h1 className="font-bold text-gray-900 text-lg tracking-tight">ThriftyThief</h1>
        </div>
        
        {activeUser && (
          <div className="flex items-center gap-2 bg-gray-100 py-1 px-2 rounded-full cursor-pointer hover:bg-gray-200 transition" onClick={() => setActiveUser(null)}>
             <img src={activeUser.avatar} alt="Me" className="w-6 h-6 rounded-full" />
             <span className="text-xs font-semibold text-gray-700 pr-1">{activeUser.name}</span>
          </div>
        )}
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-6 scrollbar-hide">
        {!activeUser ? (
          // User Selector Screen
          <div className="h-full flex flex-col justify-center animate-in zoom-in-95 duration-300">
            <h2 className="text-2xl font-bold text-center mb-8 text-gray-800">Who are you?</h2>
            <div className="grid gap-4">
              {USERS.map(user => (
                <button
                  key={user.id}
                  onClick={() => {
                    setActiveUser(user);
                    setView('dashboard');
                  }}
                  className="flex items-center gap-4 p-4 bg-white rounded-2xl shadow-sm border border-gray-100 hover:border-indigo-500 hover:ring-1 hover:ring-indigo-500 transition-all group"
                >
                  <img 
                    src={user.avatar} 
                    alt={user.name} 
                    className="w-14 h-14 rounded-full border-2 border-gray-100 group-hover:border-indigo-100 transition-colors"
                  />
                  <div className="text-left">
                    <p className="font-bold text-lg text-gray-900">{user.name}</p>
                    <p className="text-sm text-gray-400">Tap to login</p>
                  </div>
                </button>
              ))}
            </div>
            <div className="mt-8 text-center">
               <button 
                 onClick={() => {
                   setActiveUser(null);
                   setView('summary');
                 }}
                 className="text-indigo-600 font-medium text-sm hover:underline"
               >
                 Just view the Monthly Summary &rarr;
               </button>
            </div>
          </div>
        ) : (
          // Authenticated Views
          <>
            {view === 'dashboard' ? (
              <UserDashboard 
                user={activeUser} 
                expenses={expenses} 
                onAddExpense={handleAddExpense} 
              />
            ) : (
              <MonthlySummary users={USERS} expenses={expenses} />
            )}
          </>
        )}
      </main>

      {/* Bottom Navigation */}
      {(activeUser || view === 'summary') && (
        <nav className="bg-white border-t border-gray-200 pb-safe">
          <div className="flex justify-around items-center h-16">
            <button
              onClick={() => {
                if (!activeUser) setActiveUser(USERS[0]); // Default fallback if purely viewing summary
                setView('dashboard');
              }}
              className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${
                view === 'dashboard' ? 'text-indigo-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <LayoutDashboard size={24} strokeWidth={view === 'dashboard' ? 2.5 : 2} />
              <span className="text-[10px] font-medium">My Spending</span>
            </button>
            
            <button
              onClick={() => setView('summary')}
              className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${
                view === 'summary' ? 'text-indigo-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <Users size={24} strokeWidth={view === 'summary' ? 2.5 : 2} />
              <span className="text-[10px] font-medium">Group Summary</span>
            </button>
            
            <button
              onClick={() => setActiveUser(null)}
              className="flex flex-col items-center justify-center w-full h-full space-y-1 text-gray-400 hover:text-red-500 transition-colors"
            >
              <LogOut size={24} />
              <span className="text-[10px] font-medium">Switch User</span>
            </button>
          </div>
        </nav>
      )}
    </div>
  );
};

export default App;