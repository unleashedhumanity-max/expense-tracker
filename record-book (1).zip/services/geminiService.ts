import { GoogleGenAI } from "@google/genai";
import { Expense, User } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateSpendingInsight = async (
  users: User[],
  expenses: Expense[]
): Promise<string> => {
  if (!apiKey) {
    return "API Key not configured. Unable to generate insights.";
  }

  // Prepare data for the prompt
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const monthlyExpenses = expenses.filter(e => {
    const d = new Date(e.date);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  });

  const summary = users.map(user => {
    const userTotal = monthlyExpenses
      .filter(e => e.userId === user.id)
      .reduce((sum, e) => sum + e.amount, 0);
    return `${user.name} spent $${userTotal.toFixed(2)}`;
  }).join(', ');

  const prompt = `
    Analyze the following monthly spending summary for a group of housemates: ${summary}.
    
    1. Identify who is the "Thief" (highest spender).
    2. Provide a witty, lighthearted, and short commentary (max 2 sentences) roasting the highest spender or praising the lowest spender.
    3. Keep it fun and informal.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    return response.text || "Could not generate insight.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Our AI financial advisor is currently on a coffee break. Try again later.";
  }
};